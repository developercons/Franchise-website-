<footer>
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                     <h4>A propos</h4>
                    <ul>
                        <li><a href="">Qui sommes-nous ?</a> </li>
                        <li><a href="">Mentions légales</a> </li>
                        <li><a href="">CGU</a> </li>
                        <li><a href="">Nous contacter</a> </li>

                    </ul>
                </div>
                <div class="col-md-4">
                    <h4>Franchise france</h4>
                    <ul>
                        <li><a href="">Liste de franchiseurs dans le service</a> </li>
                        <li><a href="">Liste de franchiseurs dans le commerce</a> </li>
                        <li><a href="">Liste de franchiseurs dans l'habitat</a> </li>
                        <li><a href="">Ouvrir une franchise</a> </li>

                    </ul>
                </div>
                <div class="col-md-4">
                    <h4>SUIVEZ-NOUS</h4>
                    <div class="d-flex">
                        <i class="icon ion-social-facebook" ></i>
                        <i class="icon ion-social-twitter" ></i>
                        <i class="icon ion-social-googleplus" ></i>
                    </div>
                </div>
            </div>
            <div class="row ">
                <h6 class="text-center text-white w-100 mt-5">&copy FRANCHISE FRANCE 2018</h6>
            </div>
        </div>
    </footer>