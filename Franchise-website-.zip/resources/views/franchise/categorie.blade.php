@extends('layout.app')
 
@section('style')
 <link rel="stylesheet" href="{{asset('css/franchise.css')}} ">
@endsection

@section('content')
     <div class="fc-list mt-5">
         <div class="container">
            <div class="fc-item-list row">
                <div  class="item"><a href="/">Accueil</a></div>
                <div class="item"><a href="">FRANCHISE DIRECTORY </a></div>
                <div class="item"><a href="">HOME HELPERS HOME CARE </a></div>
            </div>
         </div>
     </div>
     
@endsection