<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e(setting('site.title')); ?></title>
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/mdb.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <link rel="stylesheet" href= "<?php echo e(asset('css/ionicons.min.css')); ?>">
    <?php echo $__env->yieldContent('style'); ?>
</head>
<body>
    <?php echo $__env->make('layout.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="fc-main">
        <?php echo $__env->yieldContent('content'); ?>
    </div>
    <?php echo $__env->make('layout.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('component.request-bar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <script>
    var routeAddSession = "<?php echo e(route('addRequest')); ?>" , routeRemoveSession = "<?php echo e(route('removeRequest')); ?>";
    var requetItems = [];
    var sessionData;
    <?php if(Session::has("franchiseList")): ?>
    sessionData = '<?php echo json_encode(Session::get("franchiseList"), JSON_UNESCAPED_SLASHES); ?>';
    <?php endif; ?>
    </script>
    <script src="<?php echo e(asset('js/jquery-3.2.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/mdb.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/franchise.js')); ?>"></script>
    <?php echo $__env->yieldContent('script'); ?>
    
</body>
</html>