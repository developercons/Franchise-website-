 
<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href= "<?php echo e(asset('css/home.css')); ?>">
    <style>
        .blog-image{
            max-width:100%;
            margin:0 auto;
        }
        .fc-blog {
            margin-top: 150px;
        }
        .list-group-item a{
            color:black;
        }
        .list-group-item a :hover{
            background : #f1f1f3;
            cursor:pointer;
        }
        .list-group-item:hover{
            background : #f1f1f3;
            cursor:pointer;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container fc-blog">
            <h4>Blogs</h4>
            <ul class="list-group list-group-flush mt-5">
                <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <li class="list-group-item">
                        <a href="<?php echo e(url('blogs/'.$blog->slug)); ?> ">
                            <h4><?php echo e($blog->title); ?> </h4>
                            <p class="lead small"><?php echo e($blog->excerpt); ?> </p>
                        </a>
                     </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>      

         <div class="text-center">
             <?php echo e($blogs->links()); ?>

         </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>