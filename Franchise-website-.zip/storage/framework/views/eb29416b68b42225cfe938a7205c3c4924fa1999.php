<?php $__env->startComponent('mail::message'); ?>
# Introduction

Nouveaux demande pour les documentations des franchise suivant : 

<?php
  $franchiseName = explode('-',$demande->franchiseName);
  $franchiseID = explode('-',$demande->franchiseID);
  $index =0;
?>


<div class="table">
        <table width="100%" class="center">
                <tr>
                    <th>
                        Nom franchise
                    </th>
                    <th>
                        Lien
                    </th>
                </tr>
                <?php $__currentLoopData = $franchiseName; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <?php echo e($name); ?> 
                        </td>
                        <td>
                            <a href="<?php echo e(route('singleFranchise' , 
                                    [
                                    "id" => $franchiseID[$index++],
                                    "name" => $name,
                                    "categorie"=>"all"
                                    ])); ?> ">
                                Voir
                            </a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
</div>

# Demandeur information
<div class="table">
       
        <table width="100%">
                    <tr>
                        <td><strong>NOM</strong></td>
                        <td> <?php echo e($demande->nom); ?> </td>
                    </tr>
                    <tr>
                        <td><strong>Prenom</strong></td>
                        <td> <?php echo e($demande->prenom); ?> </td>
                    </tr>
                    <tr>
                        <td><strong>Code_postal</strong></td>
                        <td> <?php echo e($demande->postal); ?> </td>
                    </tr>
                    <tr>
                        <td><strong>Ville</strong></td>
                        <td> <?php echo e($demande->ville); ?> </td>
                    </tr>
                    <tr>
                        <td><strong>Téléphone</strong></td>
                        <td> <?php echo e($demande->telephone); ?> </td>
                    </tr>
                    <tr>
                        <td><strong>Email</strong></td>
                        <td> <?php echo e($demande->email); ?> </td>
                    </tr>
                    <tr>
                        <td><strong>Secteur géographique souhaité</strong></td>
                        <td> <?php echo e($demande->secteur); ?> </td>
                    </tr>
                    <tr>
                        <td><strong>Apport personnel </strong></td>
                        <td> <?php echo e($demande->apport_select); ?> </td>
                    </tr>
                    <tr>
                        <td><strong>Avancées de votre projet </strong></td>
                        <td> <?php echo e($demande->avance_projet_select); ?> </td>
                    </tr>
                    <tr>
                        <td><strong>Parcours</strong></td>
                        <td> <?php echo e($demande->txt_parcours); ?> </td>
                    </tr>
            </table>
</div>
    


<?php echo $__env->renderComponent(); ?>
