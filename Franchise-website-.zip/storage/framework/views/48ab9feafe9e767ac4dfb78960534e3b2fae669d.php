<?php $__env->startSection('style'); ?>
 <link rel="stylesheet" href="<?php echo e(asset('/css/candidat.css')); ?> ">
 <script src="<?php echo e(asset('js/vendor/tinymce/jquery.tinymce.min.js')); ?>"></script>
 <script src="<?php echo e(asset('js/vendor/tinymce/tinymce.min.js')); ?>"></script>
 <script>
  tinymce.init({
    selector: '#mytextarea'
  });
  </script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php
 $franchiseur = Auth::guard('franchiseur')->user();
?>
  <form method="post">
    <textarea id="mytextarea">Hello, World!</textarea>
  </form>
                                        
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
      

</script>
<script src="<?php echo e(asset('js/candidat.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('franchiseur.layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>