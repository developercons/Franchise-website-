 
<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href= "<?php echo e(asset('css/select2.min.css')); ?>">
    <link rel="stylesheet" href= "<?php echo e(asset('css/owl.carousel.min.css')); ?>">
    <meta name="description" content="<?php echo e($page->meta_description); ?> ">
    <meta name="keywords" content="<?php echo e($page->meta_keywords); ?>">
    <style>
     .blog-content{
         margin-top:80px;
     }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="container blog-content">
        <h4 class="mt-5">
                <?php echo e($page->title); ?>

        </h4>
        <hr>
        <div class="content mt-4">
            <?php echo $page->body; ?>

        </div>

</div>
<?php $__env->stopSection(); ?>







<?php echo $__env->make('layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>