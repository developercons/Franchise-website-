 
<?php $__env->startSection('style'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/franchise.css')); ?> ">
<style>
    .ion-ios-checkmark-outline{
        color: #4886bd;
        font-size: 150px;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="container mt-5">
      <div class="p-5 card text-center">
            <i class="icon ion-ios-checkmark-outline mb-1"></i>
            <h3>Votre demande a été envoyé avec succés</h3>
            <p class="lead small mt-3">
                  Franchise France vous remercie et reste à votre disposition pour toute question
            </p>
      </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>