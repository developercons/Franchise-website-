<?php $__env->startSection('style'); ?>
 <link rel="stylesheet" href="<?php echo e(asset('/css/candidat.css')); ?> ">
<style>
    .bg-candidat{
        border-radius:100%;
        height:50px;
        width:50px;
        background-position: center;
        background-size: contain;
        background-repeat: no-repeat;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php
 $franchiseur = Auth::guard('franchiseur')->user();
?>
   <div class="container">
                <div class="card my-5">
                <table class="table">
                    <!--Table head-->
                    <thead>
                        <tr>
                            <th></th>
                            <th>Nom</th>
                            <th>Prenom</th>
                            <th>Disponibilité</th>
                            <th>Status</th>
                            <th>Apport personnel</th>
                            <th></th>
                        </tr>
                    </thead>
                    <!--Table head-->

                    <!--Table body-->
                    <tbody>
                         <?php $__currentLoopData = $candidats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $candidat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td> 
                                    <div class="bg-candidat" style="background-image:url(<?php echo e(url('storage/'.$candidat->image)); ?>)">

                                    </div>
                                </td>
                                <td><?php echo e($candidat->nom); ?> </td>
                                <td><?php echo e($candidat->prenom); ?> </td>
                                <td><?php echo e($candidat->disponibilite); ?> </td>
                                <td><?php echo e($candidat->status); ?> </td>
                                <td><?php echo e($candidat->apport_personnel); ?> €  </td>
                                <td>
                                    <a href="<?php echo e(route('singleCandidatPage',['id' => $candidat->id])); ?> " class="btn btn-primary">Voir</a>
                                </td>
                            </tr>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    <!--Table body-->

                </table>
                </div>
   </div>
                                        
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
      

</script>
<script src="<?php echo e(asset('js/candidat.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('franchiseur.layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>