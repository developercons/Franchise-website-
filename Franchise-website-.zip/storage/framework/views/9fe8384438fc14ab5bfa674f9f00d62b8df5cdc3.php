<?php $__env->startSection('style'); ?>
 <link rel="stylesheet" href="<?php echo e(asset('/css/candidat.css')); ?> ">
<style>
    .bg-candidat{
        border-radius:100%;
        height:100px;
        width:100px;
        background-position: center;
        background-size: contain;
        background-repeat: no-repeat;
        margin:0 auto;
    }
    p {
        margin-bottom:4px;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php
 $franchiseur = Auth::guard('franchiseur')->user();
?>
   <div class="container my-5">
        <div class="row">
            <div class="col-md-4">
                <div class="card p-3 text-center">
                    <div class="bg-candidat" style="background-image:url(<?php echo e(url('storage/'.$candidat->image)); ?>)"></div>
                    <p class="lead">Informations générales</p>
                    <div class="from-group">
                        <span class="lead small">Email</span>
                        <p><?php echo e($candidat->email); ?></p>
                    </div>
                    <div class="from-group">
                        <span class="lead small">Nom</span>
                        <p><?php echo e($candidat->nom); ?></p>
                    </div>
                    <div class="from-group">
                        <span class="lead small">Prenom</span>
                        <p><?php echo e($candidat->prenom); ?></p>
                    </div>
                    <div class="from-group">
                        <span class="lead small">Pays</span>
                        <p><?php echo e($candidat->pays); ?></p>
                    </div>
                    <div class="from-group">
                        <span class="lead small">Ville</span>
                        <p><?php echo e($candidat->ville); ?></p>
                    </div>
                    <div class="from-group">
                        <span class="lead small">Adresse</span>
                        <p><?php echo e($candidat->Adresse); ?></p>
                    </div>
                    <div class="from-group">
                        <span class="lead small">Code postal</span>
                        <p><?php echo e($candidat->code_postal); ?></p>
                    </div>
                    <div class="from-group">
                        <span class="lead small">Téléphone</span>
                        <p><?php echo e($candidat->telephone); ?></p>
                    </div>
                </div>
            </div>
            <div class="col-md-8">
                <div class="card p-4">
                    <p class="lead">Candidat information</p>
                    <div class="row mt-3">
                        <div class="col-md-6">
                            <div class="from-group">
                                <span class="lead small">Disponibilité</span>
                                <p><?php echo e(($candidat->disponibilite == 'Immediate') ? 'Immédiate' : $candidat->disponibilite); ?></p>
                            </div>
                            <div class="from-group">
                                <span class="lead small">Status</span>
                                <p><?php echo e($candidat->status); ?></p>
                            </div>
                            <div class="from-group">
                                <span class="lead small">Apport personnel</span>
                                <p><?php echo e($candidat->apport_personnel); ?> € </p>
                            </div>
                            <div class="from-group">
                                <span class="lead small">Compléments d'apports</span>
                                <p><?php echo e($candidat->complement_apport); ?> € </p>
                            </div>
                            <div class="from-group">
                                <span class="lead small">Avancées du projet</span>
                                <p><?php echo e($candidat->avance_projet); ?> </p>
                            </div>
                            <div class="from-group">
                                <span class="lead small">Projet</span>
                                <p><?php echo e($candidat->projet); ?> </p>
                            </div>
                        </div>
                        <div class="col-md-6">
                        <div class="from-group">
                                <span class="lead small">CV</span>
                                <p> <a href="<?php echo e($candidat->cv); ?> " target="_blank">CV.PDF</a> </p>
                            </div>
                             <div class="from-group">
                                <span class="lead small">CV</span>
                                <p> <a href="<?php echo e($candidat->lettre_motivation); ?> " target="_blank">Lettre motivation.PDF</a> </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
   </div>
                                        
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
      

</script>
<script src="<?php echo e(asset('js/candidat.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('franchiseur.layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>