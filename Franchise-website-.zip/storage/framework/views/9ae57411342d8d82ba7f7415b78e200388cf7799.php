 
<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href= "<?php echo e(asset('css/home.css')); ?>">
    <style>
        .blog-image{
            max-width:100%;
            margin:0 auto;
        }
        .fc-blog {
            margin-top:80px;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container fc-blog">
          <div class="text-center">
             <img src="<?php echo e(voyager::image($post->image)); ?> " alt="" class="blog-image">
        </div>
         <div class="blog-content mt-4">
               <?php echo $post->body; ?>

         </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>