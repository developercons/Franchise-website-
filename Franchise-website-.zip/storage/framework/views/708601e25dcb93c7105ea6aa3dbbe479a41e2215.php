 
<?php $__env->startSection('style'); ?>
 <link rel="stylesheet" href="<?php echo e(asset('css/franchise.css')); ?> ">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
     <div class="fc-list mt-5">
         <div class="container">
            <div class="fc-item-list row">
                <div  class="item"><a href="/">Accueil</a></div>
                <div class="item"><a href="<?php echo e(route('franchiseSecteur',['secteur' => $subcategory->name])); ?> "><?php echo e($category->name); ?> </a></div>
                <div class="item"><a href="<?php echo e(route('franchiseSecteur',['secteur' => $subcategory->name])); ?> "><?php echo e($subcategory->name); ?></a></div>
            </div>
         </div>
     </div>
     <div class="fc-detaill mt-5">
         <div class="container">
             <div class="row">
                 <div class="col-md-6">
                    <h2 class="fc-title">
                        <?php echo e($franchise->name); ?>

                    </h2>
                    <p class="lead">
                        <?php echo e($franchise->short_description); ?>

                    </p>
                 </div>
                 <div class="col-md-6 text-right">
                        <button type="button" class="btn btn-warning btn-add-request" 
                        data-id="<?php echo e($franchise->id); ?>"
                        data-name="<?php echo e($franchise->name); ?>">
                        DEMANDER UNE DOCUMENTATION</button>
                 </div>
             </div>
             <div class="row mt-4">
                 <div class="col-md-3">
                     <img src="<?php echo e(Voyager::image($franchise->image)); ?>" class="mx-auto">
                 </div>
                 <div class="col-md-9">
                     <div class="row">
                         <div class="col-md-4">
                             <div class="d-flex align-items-center">
                                <i class="icon ion-social-euro"></i>                                
                                 <div class="fc-info">
                                     <p>APPORT PERSONNEL</p>
                                     <p class="fc-price"><?php echo e($franchise->apport_personnel); ?> €</p>
                                 </div>
                             </div>
                         </div>
                         <div class="col-md-4">
                            <div class="d-flex align-items-center">
                               <i class="icon ion-social-euro-outline"></i>                                
                                <div class="fc-info">
                                    <p>AIDE AU FINANCEMENT</p>
                                    <p class="fc-price fc-bool">
                                        <?php if($franchise->aide_financement == 0): ?>
                                         NON
                                        <?php else: ?>
                                        OUI
                                        <?php endif; ?>
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="d-flex align-items-center">
                               <i class="icon ion-ios-pulse-strong"></i>                                
                                <div class="fc-info">
                                    <p>INVESTISSEMENT GLOBAL</p>
                                    <p class="fc-price"><?php echo e($franchise->investissment_global); ?> €</p>
                                </div>
                            </div>
                        </div>
                     </div>
                     <div class="row">
                         <div class="col-md-4">
                                <div class="d-flex align-items-center">
                                    <i class="icon ion-podium"></i>                                
                                    <div class="fc-info">
                                        <p>DROITS D’ENTRÉE</p>
                                        <p class="fc-price"><?php echo e($franchise->investissment_global); ?> €</p>
                                    </div>
                                </div>
                         </div>
                            <div class="col-md-4">
                                <div class="d-flex align-items-center">
                                    <i class="icon ion-briefcase"></i>                                
                                    <div class="fc-info">
                                        <p>FORMATION</p>
                                        <p class="fc-price fc-bool">
                                                <?php if($franchise->formation == 0): ?>
                                                NON
                                               <?php else: ?>
                                               OUI
                                               <?php endif; ?>
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="d-flex align-items-center">
                                    <i class="icon ion-arrow-graph-up-right"></i>                                
                                    <div class="fc-info">
                                        <p>CA RÉALISABLE APRÈS 2 ANS</p>
                                        <p class="fc-price"><?php echo e($franchise->last_realisation); ?> €</p>
                                    </div>
                                </div>
                            </div>
                         </div>
                        <div class="row fc-second-ref">
                            <div class="col-md-4">
                                <p>Redevance fonctionnement : <br><span class="fc-price"> <?php echo e($franchise->redevance_fonctionnement); ?>% du CA HT</span></p>
                            </div>
                            <div class="col-md-4">
                                <p>Surface moyenne:<br><span class="fc-price"> <?php echo e($franchise->surface); ?>  m²</span></p>
                            </div>
                            <div class="col-md-4">
                                <p>Type de contrat  : <br><span class="fc-price"> <?php echo e($franchise->type_contract); ?> </span></p>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-4">
                                 <p>Redevance publicitaire :<span class="fc-price"> <?php echo e($franchise->redevance_publicitaire); ?>   </span></p>
                            </div>
                            <div class="col-md-4">
                                <p>Royalties  : <span class="fc-price"> <?php echo e($franchise->royalties); ?></span></p>
                            </div>
                        </div>
                     </div>
                 </div>
             </div>
         </div>
     </div>
      
    <?php if($franchise->CONCEPT): ?>
            <div class="container mt-5 fc-tabs">
                <ul class="nav nav-tabs nav-justified indigo mt-4" id="fc-tabs" role="tablist">
                    <li class="nav-item">
                        <a class="nav-link active" data-target="concept" role="tab">
                        <i class="fa fa-user"></i> CONCEPT</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" data-target="caracterstique" role="tab">
                        <i class="fa fa-heart"></i> Caractéristiques</a>
                    </li>
                </ul>
            
                <div class="tab-content">
                    <div class="tab-pane fade in show active" id="concept" role="tabpanel">
                        <div class="p-3">
                            <?php echo $franchise->CONCEPT; ?>

                        </div>
            
                    </div>
            
                    <div class="tab-pane fade" id="caracterstique" role="tabpanel">
                        <div class="p-3">
                            <?php echo $franchise->caracteristique; ?>

                        </div>
                    </div>
            
                </div>
            </div>
    <?php endif; ?>
    

     
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<script>
    $('#fc-tabs a').click(function (e) {
        e.preventDefault();
        $('#fc-tabs a').removeClass("show active");
        $(this).addClass("show active");
        $target = $(this).data('target');
        $(".tab-pane").removeClass("show active");
        $("#"+$target).addClass("show active");
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>