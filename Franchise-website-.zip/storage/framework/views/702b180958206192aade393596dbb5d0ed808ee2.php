<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/mdb.min.css')); ?>">
    <link rel="stylesheet" href= "<?php echo e(asset('css/ionicons.min.css')); ?>">
    <link rel="stylesheet" href= "<?php echo e(asset('css/candidatheque.css')); ?>">
    <?php echo $__env->yieldContent('style'); ?>
</head>
<body>
    <nav class="mb-1 navbar navbar-expand-lg lighten-1 p-4">
        <a class="navbar-brand" href="<?php echo e(url('/')); ?> ">FRANCHISE FRANCE</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent-5" aria-controls="navbarSupportedContent-5" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent-5">
            <?php if(Auth::guard('candidat')->check()): ?>
                <ul class="navbar-nav ml-auto nav-flex-icons align-items-center">
                    <li class="nav-item">
                        <a class="nav-link waves-effect waves-light d-flex align-items-center" href="<?php echo e(url('candidatheque/candidat')); ?>">
                          <div style="background-image:url(<?php echo e(asset('storage/'.Auth::guard('candidat')->user()->image)); ?>)" class="bg-user rounded-circle z-depth-0" alt="avatar image"> </div>
                          Bonjour, <?php echo e(Auth::guard('candidat')->user()->nom); ?> 
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link waves-effect waves-light" href="<?php echo e(url('candidatheque/candidat')); ?>"><i class="icon ion-android-options"></i> Tableau de bord</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link waves-effect waves-light" href="<?php echo e(route('candidatLogout')); ?>"><i class="icon ion-log-in"></i> Déconnexion</a>
                    </li>
                </ul>
            <?php else: ?>
                <ul class="navbar-nav ml-auto nav-flex-icons">
                    <li class="nav-item">
                        <a href="<?php echo e(url('http://localhost:8000/candidatheque/candidat/login')); ?>" class="nav-link waves-effect waves-light d-flex align-items-center ">
                           <div class="icon-round mr-1">
                            <i class="icon ion-person mr-1"></i>
                           </div>
                            Mon compte Candidat
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link waves-effect waves-light d-flex align-items-center ">
                            <div class="icon-round mr-1">
                             <i class="icon ion-ios-people mr-1"></i>
                            </div>
                            Mon compte Franchiseur
                         </a>
                    </li>
                </ul> 
            <?php endif; ?>
        </div>
    </nav>

     <?php echo $__env->yieldContent('content'); ?>

    <?php echo $__env->make('layout.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <script src="<?php echo e(asset('js/jquery-3.2.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/mdb.min.js')); ?>"></script>
    <?php echo $__env->yieldContent('script'); ?>
</body>
</html>