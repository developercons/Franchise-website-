 
<?php $__env->startSection('style'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/franchise.css')); ?> ">
<style>
    .fc-request-wrapper{
        display: none !important;
    }
    .lead {
        color: #47525d;
    }
    .list-group-item{
        text-align: center;
        border: none;
        font-size: 20px;
        padding: 0;
        margin: 0;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
   <?php if(Session::has("franchiseList") && count(Session::get('franchiseList')) > 0): ?>
    <div class="container">
            <h4 class="mt-5 text-center">Je souhaite de l'information sur le réseau suivant, gratuitement et sans engagement :            </h4>
            <div class="row mt-2">
               <div class="fc-list-group-request w-100">
               </div>
            </div>
            <div class="row mt-5">
                <form class="form-horizontal col-12 card p-5" role="form" method="POST" action="<?php echo e(url('franchise/Demande')); ?>">
                    <?php echo e(csrf_field()); ?>

                    <?php if(count($errors) > 0): ?>
                     <span class="error">
                        Veuillez remplir tous les champs
                     </span>
                    <?php endif; ?>
                    <p class="lead small m-0 mb-2">
                    Les franchiseurs, responsables du développement sont attentifs à la qualité de votre candidature : soyez clairs, motivez votre projet et renseignez bien les champs demandés.
                    </p>
                    <div class=" form-group ">
                              <label for="select">Êtes-vous* </label>
                              <select class="form-control" name="ev_select" id="" value="<?php echo e(old('ev_select')); ?>">
                                <option disabled selected>Êtes-vous</option>
                                <option value="Dirigeant">Dirigeant</option>
                                <option value="Salarié">Salarié</option>
                              </select>
                            <?php if($errors->has('ev_select')): ?>
                                <span class="help-block error">
                                    <strong><?php echo e($errors->first('ev_select')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    <div class="md-form form-group mt-5">
                        <input type="text" class="form-control" name="nom" id="nom" placeholder="Votre Nom" value="<?php echo e(old('nom')); ?>">
                        <label for="nom">Nom* </label>
                        <?php if($errors->has('nom')): ?>
                            <span class="help-block error">
                                <strong><?php echo e($errors->first('nom')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                    <div class="md-form form-group mt-5">
                        <input type="text" class="form-control" name="prenom" id="Prenom" placeholder="Votre Prenom" value="<?php echo e(old('prenom')); ?>">
                        <label for="Prenom">Prenom* </label>
                        <?php if($errors->has('prenom')): ?>
                            <span class="help-block error">
                                <strong><?php echo e($errors->first('prenom')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                    <div class="md-form form-group mt-5">
                        <input type="text" class="form-control" name="address" id="Adresse" placeholder="Votre Adresse" value="<?php echo e(old('address')); ?>">
                        <label for="Adresse">Adresse* </label>
                        <?php if($errors->has('address')): ?>
                            <span class="help-block error">
                                <strong><?php echo e($errors->first('address')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                    <div class="row">
                        <div class="col-4">
                                <div class="md-form form-group mt-5">
                                    <input type="text" class="form-control" name="postal" id="Code Postal" placeholder="Votre Code Postal" value="<?php echo e(old('postal')); ?>">
                                    <label for="Code Postal">Code Postal* </label>
                                    <?php if($errors->has('postal')): ?>
                                        <span class="help-block error">
                                            <strong><?php echo e($errors->first('postal')); ?></strong>
                                        </span>
                                    <?php endif; ?>  
                                </div>
                            </div>
                            <div class="col-8">
                                <div class="md-form form-group mt-5">
                                    <input type="text" class="form-control" name="ville" id="Ville" placeholder="Votre Ville" value="<?php echo e(old('ville')); ?>">
                                    <label for="Ville">Ville* </label>
                                    <?php if($errors->has('ville')): ?>
                                        <span class="help-block error">
                                            <strong><?php echo e($errors->first('ville')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                    </div>
                    <div class="md-form form-group mt-5">
                        <input type="text" class="form-control" id="Téléphone" name="telephone" placeholder="Votre Téléphone" value="<?php echo e(old('telephone')); ?>">
                        <label for="Téléphone">Téléphone* </label>
                        <?php if($errors->has('telephone')): ?>
                            <span class="help-block error">
                                <strong><?php echo e($errors->first('telephone')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                    <div class="md-form form-group mt-5">
                        <input type="email" class="form-control" name="email" id="Email" placeholder="Votre Email" value="<?php echo e(old('email')); ?>">
                        <label for="Email">Email* </label>
                        <?php if($errors->has('email')): ?>
                            <span class="help-block error">
                                <strong><?php echo e($errors->first('email')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                    <p class="lead small mt-1">
                        Ces informations sont importantes car elles vont nous permettre de transmettre, ou non, votre dossier vers le(s) franchiseur(s) en fonction des différents critères imposés par l'enseigne. Soyez précis.
                    </p>
                    <div class="md-form form-group ">
                        <input type="text" class="form-control" name="secteur" id="secteur" placeholder="Secteur géographique souhaité " value="<?php echo e(old('secteur')); ?>">
                        <label for="secteur">Secteur* </label>
                        <?php if($errors->has('secteur')): ?>
                            <span class="help-block error">
                                <strong><?php echo e($errors->first('secteur')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                    <div class=" form-group ">
                            <label for="select">Apport personnel * </label>
                            <select class="form-control" name="apport_select" id="" value="<?php echo e(old('apport_select')); ?>">
                                    <option value="" disabled selected>Apport personnel</option>
                                    <option value="5000">jusqu'a 5 000 €</option>
                                    <option value="10000">jusqu'a 10 000 €</option>
                                    <option value="20000">jusqu'a 20 000 €</option>
                                    <option value="30000">jusqu'a 30 000 €</option>
                                    <option value="50000">jusqu'a 50 000 €</option>
                                    <option value="8000">jusqu'a 80 000 €</option>
                                    <option value="100000">jusqu'a 100 000 €</option>
                                    <option value="150000">jusqu'a 150 000 €</option>
                                    <option value="200000">jusqu'a 200 000 €</option>
                                    <option value="500000">jusqu'a 500 000 €</option>
                            </select>
                          <?php if($errors->has('apport_select')): ?>
                              <span class="help-block error">
                                  <strong><?php echo e($errors->first('apport_select')); ?></strong>
                              </span>
                          <?php endif; ?>
                      </div>
                      <div class=" form-group ">
                            <label for="select">Avancées de votre projet * </label>
                            <select class="form-control" name="avance_projet_select" id=""> value="<?php echo e(old('avance_projet_select')); ?>"
                              <option disabled selected>Avancées de votre projet </option>
                              <option value="documentation">Recherche de documentation</option>
                              <option value="creation">Projet de création</option>
                            </select>
                          <?php if($errors->has('avance_projet_select')): ?>
                              <span class="help-block error">
                                  <strong><?php echo e($errors->first('avance_projet_select')); ?></strong>
                              </span>
                          <?php endif; ?>
                      </div>
                      <div class="md-form">
                            <textarea type="text" id="form7" name="txt_parcours" class="md-textarea form-control" rows="3" value="<?php echo e(old('txt-parcours')); ?>"></textarea>
                            <label for="form7">Votre parcours, votre projet* </label>
                            <?php if($errors->has('txt-parcours')): ?>
                              <span class="help-block error">
                                  <strong><?php echo e($errors->first('txt_parcours')); ?></strong>
                              </span>
                          <?php endif; ?>
                     </div>
                     <div class="list-franchise-request">
                          
                         <?php $__currentLoopData = Session::get("franchiseList"); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $franchise): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <input type="hidden" value="<?php echo e($franchise['id']); ?> " name="franchiseID[]">
                           <input type="hidden" value="<?php echo e($franchise['name']); ?> " name="franchiseName[]">
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </div>
                    <div class="form-group text-right">
                            <button type="submit" class="btn btn-primary">
                                ENVOYER
                            </button>
                    </div>
                    <p class="lead small mt-2   ">
                            Franchise France est le leader de la mise à relation entre les candidats à la franchise et les franchiseurs depuis 10 ans. Nous avons déjà aidé plus de 50.000 candidats à se lancer. Vos coordonnées seront uniquement envoyées aux franchiseurs sélectionnés. Elles ne seront ni divulguées à des tiers, ni vendues.
                    </p>
                </form>
            </div>
    </div>
    <?php else: ?>
       <div class="container my-5">
           <h3 class="text-center">Vous n'avez selectionner aucune franchise</h3>
           <h4 class="text-center">
               <a href="<?php echo e(route('franchiseIndex')); ?> ">Cliquer ici</a>
               pour selectionner une franchise
           </h4>
       </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>